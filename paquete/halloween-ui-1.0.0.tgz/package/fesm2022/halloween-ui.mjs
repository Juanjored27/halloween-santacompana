import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.imagen = "";
		this.titulo = "";
		this.texto = "";
		this.etiqueta = "";
		this.botonTexto = "Abrir el expediente";
		this.accion = new EventEmitter();
	}
	pulsar() {
		this.accion.emit(this.titulo);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.4",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "17.0.0",
			version: "22.2.4",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "hallow-monster-card",
			inputs: {
				imagen: "imagen",
				titulo: "titulo",
				texto: "texto",
				etiqueta: "etiqueta",
				botonTexto: "botonTexto"
			},
			outputs: { accion: "accion" },
			ngImport: i0,
			template: "<article class=\"tarjeta\">\n  <span class=\"esquina esquina--tl\"></span>\n  <span class=\"esquina esquina--tr\"></span>\n  <span class=\"esquina esquina--bl\"></span>\n  <span class=\"esquina esquina--br\"></span>\n\n  <!-- Brillo de cirio que se mueve despacio por detras del contenido -->\n  <span class=\"brillo\" aria-hidden=\"true\"></span>\n\n  <!-- Silueta de anima encapuchada de fondo -->\n  <svg class=\"anima\" viewBox=\"0 0 200 320\" aria-hidden=\"true\">\n    <path d=\"M100 0 C 60 0 34 46 34 104 C 34 158 16 214 0 260 L 0 320 L 200 320 L 200 260 C 184 214 166 158 166 104 C 166 46 140 0 100 0 Z\" fill=\"currentColor\"/>\n    <ellipse cx=\"78\" cy=\"112\" rx=\"22\" ry=\"30\" fill=\"#05030a\"/>\n  </svg>\n\n  @if (imagen) {\n    <figure class=\"figura\">\n      <img [src]=\"imagen\" [alt]=\"titulo\" loading=\"lazy\" />\n      <span class=\"figura__velo\"></span>\n    </figure>\n  }\n\n  <div class=\"cuerpo\">\n    @if (etiqueta) {\n      <span class=\"etiqueta\">{{ etiqueta }}</span>\n    }\n\n    <h3 class=\"titulo\">{{ titulo }}</h3>\n\n    <div class=\"filete\" aria-hidden=\"true\"><span></span></div>\n\n    <p class=\"texto\">{{ texto }}</p>\n\n    <button class=\"boton\" type=\"button\" (click)=\"pulsar()\">\n      <svg class=\"boton__icono\" viewBox=\"0 0 24 24\" aria-hidden=\"true\">\n        <path d=\"M12 2c1.6 3.2 4.6 5.1 4.6 9.2A4.6 4.6 0 0 1 12 16a4.6 4.6 0 0 1-4.6-4.8C7.4 7.1 10.4 5.2 12 2Z\" fill=\"currentColor\"/>\n        <path d=\"M12 10c.8 1.4 1.9 2.2 1.9 3.6A1.9 1.9 0 0 1 12 15.4a1.9 1.9 0 0 1-1.9-1.8C10.1 12.2 11.2 11.4 12 10Z\" fill=\"#2b1a0a\"/>\n        <path d=\"M3 21h18\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\"/>\n      </svg>\n      {{ botonTexto }}\n    </button>\n  </div>\n</article>\n",
			styles: [":host{display:block;--tinta: #efe6d6;--cirio: #ffc46b;--sangre: #8d1424;--morado: #241640;font-family:EB Garamond,Georgia,Times New Roman,serif}.tarjeta{position:relative;overflow:hidden;display:flex;flex-direction:column;padding:2px;border-radius:18px;background:linear-gradient(150deg,#ffc46ba6,#8d142473 38%,#241640d9 72%,#ffc46b66);box-shadow:0 14px 34px #000000b3,0 0 22px #ff9a2e1f;transition:transform .25s ease,box-shadow .25s ease}.tarjeta:active{transform:scale(.97);box-shadow:0 6px 18px #000c,0 0 40px #ff9a2e59}@media(hover:hover){.tarjeta:hover{transform:translateY(-4px);box-shadow:0 20px 44px #000000bf,0 0 34px #ff9a2e40}}.brillo{position:absolute;inset:-40% -10% auto;height:70%;background:radial-gradient(circle at 70% 50%,rgba(255,196,107,.18),transparent 62%);animation:llamear 7s ease-in-out infinite;pointer-events:none}@keyframes llamear{0%,to{opacity:.5;transform:scale(1)}50%{opacity:.95;transform:scale(1.08)}}.anima{position:absolute;right:-16px;bottom:-30px;width:44%;color:#b9c6e6;opacity:.07;pointer-events:none}.esquina{position:absolute;width:18px;height:18px;border:2px solid rgba(255,196,107,.75);pointer-events:none;z-index:3}.esquina--tl{top:8px;left:8px;border-right:0;border-bottom:0;border-radius:6px 0 0}.esquina--tr{top:8px;right:8px;border-left:0;border-bottom:0;border-radius:0 6px 0 0}.esquina--bl{bottom:8px;left:8px;border-right:0;border-top:0;border-radius:0 0 0 6px}.esquina--br{bottom:8px;right:8px;border-left:0;border-top:0;border-radius:0 0 6px}.figura{position:relative;margin:0;aspect-ratio:16/10;max-height:240px;overflow:hidden;border-radius:16px 16px 0 0;background:#0a0712}.figura img{width:100%;height:100%;object-fit:cover;filter:saturate(.85) contrast(1.05);transition:transform .6s ease}.tarjeta:hover .figura img{transform:scale(1.05)}.figura__velo{position:absolute;inset:0;background:linear-gradient(to top,#0b0714 4%,rgba(11,7,20,.35) 45%,transparent 80%)}.cuerpo{position:relative;z-index:2;padding:16px 18px 20px;background:linear-gradient(180deg,#0d0917,#0a0712);border-radius:0 0 16px 16px}.etiqueta{display:inline-block;margin-bottom:8px;padding:3px 10px;font-family:Cinzel,Georgia,serif;font-size:.66rem;letter-spacing:.18em;text-transform:uppercase;color:#ffd89a;border:1px solid rgba(255,196,107,.5);border-radius:999px;background:#8d142438}.titulo{margin:0;font-family:Cinzel Decorative,Cinzel,Georgia,serif;font-size:1.22rem;line-height:1.25;letter-spacing:.01em;color:var(--tinta);text-shadow:0 2px 12px rgba(0,0,0,.8)}.filete{display:block;height:1px;margin:10px 0 12px;background:linear-gradient(90deg,rgba(255,196,107,.7),rgba(141,20,36,.45),transparent)}.texto{margin:0 0 16px;font-size:.95rem;line-height:1.55;color:#cdc4bd}.boton{display:inline-flex;align-items:center;gap:8px;padding:9px 18px;font-family:Cinzel,Georgia,serif;font-size:.74rem;letter-spacing:.14em;text-transform:uppercase;color:#ffd89a;cursor:pointer;background:linear-gradient(180deg,#8d142480,#3c0a14b3);border:1px solid rgba(255,196,107,.55);border-radius:4px;box-shadow:inset 0 0 12px #ff9a2e26,0 2px 10px #0009;transition:background .2s ease,box-shadow .2s ease,color .2s ease,transform .12s ease}.boton:hover{color:#fff3dc;background:linear-gradient(180deg,#b41e3299,#5a0c18d9);box-shadow:inset 0 0 16px #ff9a2e4d,0 0 18px #ff9a2e4d}.boton:active{transform:translateY(1px) scale(.98);box-shadow:inset 0 0 22px #ff9a2e80}.boton:focus-visible{outline:2px solid #ffd89a;outline-offset:3px}.boton__icono{width:15px;height:15px;color:#ffb54d;filter:drop-shadow(0 0 5px rgba(255,154,46,.8))}@media(prefers-reduced-motion:reduce){.brillo{animation:none}.tarjeta,.figura img,.boton{transition:none}}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "hallow-monster-card",
			standalone: true,
			template: "<article class=\"tarjeta\">\n  <span class=\"esquina esquina--tl\"></span>\n  <span class=\"esquina esquina--tr\"></span>\n  <span class=\"esquina esquina--bl\"></span>\n  <span class=\"esquina esquina--br\"></span>\n\n  <!-- Brillo de cirio que se mueve despacio por detras del contenido -->\n  <span class=\"brillo\" aria-hidden=\"true\"></span>\n\n  <!-- Silueta de anima encapuchada de fondo -->\n  <svg class=\"anima\" viewBox=\"0 0 200 320\" aria-hidden=\"true\">\n    <path d=\"M100 0 C 60 0 34 46 34 104 C 34 158 16 214 0 260 L 0 320 L 200 320 L 200 260 C 184 214 166 158 166 104 C 166 46 140 0 100 0 Z\" fill=\"currentColor\"/>\n    <ellipse cx=\"78\" cy=\"112\" rx=\"22\" ry=\"30\" fill=\"#05030a\"/>\n  </svg>\n\n  @if (imagen) {\n    <figure class=\"figura\">\n      <img [src]=\"imagen\" [alt]=\"titulo\" loading=\"lazy\" />\n      <span class=\"figura__velo\"></span>\n    </figure>\n  }\n\n  <div class=\"cuerpo\">\n    @if (etiqueta) {\n      <span class=\"etiqueta\">{{ etiqueta }}</span>\n    }\n\n    <h3 class=\"titulo\">{{ titulo }}</h3>\n\n    <div class=\"filete\" aria-hidden=\"true\"><span></span></div>\n\n    <p class=\"texto\">{{ texto }}</p>\n\n    <button class=\"boton\" type=\"button\" (click)=\"pulsar()\">\n      <svg class=\"boton__icono\" viewBox=\"0 0 24 24\" aria-hidden=\"true\">\n        <path d=\"M12 2c1.6 3.2 4.6 5.1 4.6 9.2A4.6 4.6 0 0 1 12 16a4.6 4.6 0 0 1-4.6-4.8C7.4 7.1 10.4 5.2 12 2Z\" fill=\"currentColor\"/>\n        <path d=\"M12 10c.8 1.4 1.9 2.2 1.9 3.6A1.9 1.9 0 0 1 12 15.4a1.9 1.9 0 0 1-1.9-1.8C10.1 12.2 11.2 11.4 12 10Z\" fill=\"#2b1a0a\"/>\n        <path d=\"M3 21h18\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\"/>\n      </svg>\n      {{ botonTexto }}\n    </button>\n  </div>\n</article>\n",
			styles: [":host{display:block;--tinta: #efe6d6;--cirio: #ffc46b;--sangre: #8d1424;--morado: #241640;font-family:EB Garamond,Georgia,Times New Roman,serif}.tarjeta{position:relative;overflow:hidden;display:flex;flex-direction:column;padding:2px;border-radius:18px;background:linear-gradient(150deg,#ffc46ba6,#8d142473 38%,#241640d9 72%,#ffc46b66);box-shadow:0 14px 34px #000000b3,0 0 22px #ff9a2e1f;transition:transform .25s ease,box-shadow .25s ease}.tarjeta:active{transform:scale(.97);box-shadow:0 6px 18px #000c,0 0 40px #ff9a2e59}@media(hover:hover){.tarjeta:hover{transform:translateY(-4px);box-shadow:0 20px 44px #000000bf,0 0 34px #ff9a2e40}}.brillo{position:absolute;inset:-40% -10% auto;height:70%;background:radial-gradient(circle at 70% 50%,rgba(255,196,107,.18),transparent 62%);animation:llamear 7s ease-in-out infinite;pointer-events:none}@keyframes llamear{0%,to{opacity:.5;transform:scale(1)}50%{opacity:.95;transform:scale(1.08)}}.anima{position:absolute;right:-16px;bottom:-30px;width:44%;color:#b9c6e6;opacity:.07;pointer-events:none}.esquina{position:absolute;width:18px;height:18px;border:2px solid rgba(255,196,107,.75);pointer-events:none;z-index:3}.esquina--tl{top:8px;left:8px;border-right:0;border-bottom:0;border-radius:6px 0 0}.esquina--tr{top:8px;right:8px;border-left:0;border-bottom:0;border-radius:0 6px 0 0}.esquina--bl{bottom:8px;left:8px;border-right:0;border-top:0;border-radius:0 0 0 6px}.esquina--br{bottom:8px;right:8px;border-left:0;border-top:0;border-radius:0 0 6px}.figura{position:relative;margin:0;aspect-ratio:16/10;max-height:240px;overflow:hidden;border-radius:16px 16px 0 0;background:#0a0712}.figura img{width:100%;height:100%;object-fit:cover;filter:saturate(.85) contrast(1.05);transition:transform .6s ease}.tarjeta:hover .figura img{transform:scale(1.05)}.figura__velo{position:absolute;inset:0;background:linear-gradient(to top,#0b0714 4%,rgba(11,7,20,.35) 45%,transparent 80%)}.cuerpo{position:relative;z-index:2;padding:16px 18px 20px;background:linear-gradient(180deg,#0d0917,#0a0712);border-radius:0 0 16px 16px}.etiqueta{display:inline-block;margin-bottom:8px;padding:3px 10px;font-family:Cinzel,Georgia,serif;font-size:.66rem;letter-spacing:.18em;text-transform:uppercase;color:#ffd89a;border:1px solid rgba(255,196,107,.5);border-radius:999px;background:#8d142438}.titulo{margin:0;font-family:Cinzel Decorative,Cinzel,Georgia,serif;font-size:1.22rem;line-height:1.25;letter-spacing:.01em;color:var(--tinta);text-shadow:0 2px 12px rgba(0,0,0,.8)}.filete{display:block;height:1px;margin:10px 0 12px;background:linear-gradient(90deg,rgba(255,196,107,.7),rgba(141,20,36,.45),transparent)}.texto{margin:0 0 16px;font-size:.95rem;line-height:1.55;color:#cdc4bd}.boton{display:inline-flex;align-items:center;gap:8px;padding:9px 18px;font-family:Cinzel,Georgia,serif;font-size:.74rem;letter-spacing:.14em;text-transform:uppercase;color:#ffd89a;cursor:pointer;background:linear-gradient(180deg,#8d142480,#3c0a14b3);border:1px solid rgba(255,196,107,.55);border-radius:4px;box-shadow:inset 0 0 12px #ff9a2e26,0 2px 10px #0009;transition:background .2s ease,box-shadow .2s ease,color .2s ease,transform .12s ease}.boton:hover{color:#fff3dc;background:linear-gradient(180deg,#b41e3299,#5a0c18d9);box-shadow:inset 0 0 16px #ff9a2e4d,0 0 18px #ff9a2e4d}.boton:active{transform:translateY(1px) scale(.98);box-shadow:inset 0 0 22px #ff9a2e80}.boton:focus-visible{outline:2px solid #ffd89a;outline-offset:3px}.boton__icono{width:15px;height:15px;color:#ffb54d;filter:drop-shadow(0 0 5px rgba(255,154,46,.8))}@media(prefers-reduced-motion:reduce){.brillo{animation:none}.tarjeta,.figura img,.boton{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		imagen: [{ type: Input }],
		titulo: [{ type: Input }],
		texto: [{ type: Input }],
		etiqueta: [{ type: Input }],
		botonTexto: [{ type: Input }],
		accion: [{ type: Output }]
	}
});
export { MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map