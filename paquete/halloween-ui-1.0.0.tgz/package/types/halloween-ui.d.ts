import * as i0 from "@angular/core";
import { EventEmitter } from "@angular/core";
export declare class MonsterCardComponent {
  imagen: string;
  titulo: string;
  texto: string;
  etiqueta: string;
  botonTexto: string;
  accion: EventEmitter<string>;
  pulsar(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "hallow-monster-card", never, {
    "imagen": {
      "alias": "imagen";
      "required": false;
    };
    "titulo": {
      "alias": "titulo";
      "required": false;
    };
    "texto": {
      "alias": "texto";
      "required": false;
    };
    "etiqueta": {
      "alias": "etiqueta";
      "required": false;
    };
    "botonTexto": {
      "alias": "botonTexto";
      "required": false;
    };
  }, {
    "accion": "accion";
  }, never, never, true, never>;
}